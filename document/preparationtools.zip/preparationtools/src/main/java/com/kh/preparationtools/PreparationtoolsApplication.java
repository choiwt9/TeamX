package com.kh.preparationtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreparationtoolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreparationtoolsApplication.class, args);
	}

}
