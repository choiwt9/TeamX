package com.kh.preparationtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreparationtoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
